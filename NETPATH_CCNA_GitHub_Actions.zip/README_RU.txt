NETPATH CCNA — Android-проект

Это проект Android-приложения, оборачивающий учебный интерфейс в WebView. Сам APK в этой среде не скомпилирован, потому что Android SDK и Gradle здесь не установлены.

Как получить APK:
1. Установи Android Studio на компьютер.
2. Распакуй архив и открой в Android Studio папку NETPATH_CCNA_Android (именно папку проекта, где settings.gradle).
3. Дождись Gradle Sync. При запросе установи Android SDK Platform 35 и Build Tools.
4. Выбери Build > Build Bundle(s) / APK(s) > Build APK(s).
5. После сборки нажми Locate в уведомлении. Обычно APK появится в app/build/outputs/apk/debug/app-debug.apk.
6. Передай APK на Android-телефон и разреши установку из этого источника, если телефон спросит.

Прогресс хранится локально в WebView на устройстве. Для Cisco CLI-лабораторных используй Packet Tracer или другую совместимую среду — приложение содержит пошаговые задания и проверки, но не эмулирует IOS внутри себя.
